<script lang="ts">
	import { PUBLIC_APP_ORIGIN } from '$env/static/public';
	import { page } from '$app/state';
	import { resolve } from '$app/paths';
	import Icon from '@iconify/svelte';
	import { Card, CardContent } from '$lib/components/ui/card';

	const token = $derived(page.url.searchParams.get('token'));
	// Default callback lands on the app (dashboard) host, not the current host.
	const defaultCallback = PUBLIC_APP_ORIGIN ? `${PUBLIC_APP_ORIGIN}/vendors` : '/vendors';
	const callbackURL = $derived(page.url.searchParams.get('callbackURL') ?? defaultCallback);

	// Build the real better-auth verify URL - navigating here creates the session
	const verifyHref = $derived(
		token
			? `/api/auth/magic-link/verify?token=${encodeURIComponent(token)}&callbackURL=${encodeURIComponent(callbackURL)}`
			: null
	);
</script>

<Card>
	<CardContent class="p-8 text-center">
		{#if !token || !verifyHref}
			<Icon icon="mdi:link-off" class="mx-auto mb-3 h-8 w-8 text-muted-foreground/40" />
			<p class="text-sm font-medium text-muted-foreground">Invalid link</p>
			<p class="mt-1 text-sm text-muted-foreground">This sign-in link is missing or malformed.</p>
			<a href={resolve('/login')} class="mt-4 inline-block text-sm text-primary hover:underline"
				>Back to sign in</a
			>
		{:else}
			<Icon icon="mdi:email-check-outline" class="mx-auto mb-3 h-8 w-8 text-primary/80" />
			<p class="text-sm font-medium text-muted-foreground">Ready to sign in</p>
			<p class="mt-1 mb-5 text-sm text-muted-foreground">
				Click the button below to complete your sign-in.
			</p>
			<a
				href={resolve(verifyHref as `/${string}`)}
				class="block w-full rounded-lg bg-gray-900 px-4 py-2.5 text-sm font-medium text-white transition-colors hover:bg-gray-700"
			>
				Sign in to Order Local
			</a>
		{/if}
	</CardContent>
</Card>
