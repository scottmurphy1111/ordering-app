<script lang="ts">
	import { onMount } from 'svelte';
	import type { PageData } from './$types';
	import {
		cart,
		CartTypeMismatchError,
		type PickupType,
		type CartModifier,
		type AvailabilityMode
	} from '$lib/cart.svelte';
	import { confirmDialog } from '$lib/confirm.svelte';
	import { resolve } from '$app/paths';
	import Icon from '@iconify/svelte';

	let { data }: { data: PageData } = $props();

	onMount(() => cart.init(data.vendorSlug));

	const vendor = $derived(data.vendor);
	const isPaused = $derived(!!data.vendor.subscriptionPausedAt);

	// ── Category/item data ───────────────────────────────────────────────────
	const categorized = $derived(
		data.categories
			.map((cat) => ({ ...cat, items: data.itemsByCategory[cat.id] ?? [] }))
			.filter((c) => c.items.length > 0)
	);
	const visibleCategoryIds = $derived(new Set(data.categories.map((c) => c.id)));
	const uncategorized = $derived(
		data.items.filter((item) => !item.categoryId || !visibleCategoryIds.has(item.categoryId))
	);

	// ── Search ───────────────────────────────────────────────────────────────
	let searchQuery = $state('');

	function matchesQuery(item: { name: string; description?: string | null }, q: string) {
		const lq = q.toLowerCase();
		return (
			item.name.toLowerCase().includes(lq) ||
			(item.description?.toLowerCase().includes(lq) ?? false)
		);
	}

	const filteredCategorized = $derived(
		searchQuery.trim()
			? categorized
					.map((cat) => ({
						...cat,
						items: cat.items.filter((i: (typeof cat.items)[number]) => matchesQuery(i, searchQuery))
					}))
					.filter((cat) => cat.items.length > 0)
			: categorized
	);
	const filteredUncategorized = $derived(
		searchQuery.trim() ? uncategorized.filter((i) => matchesQuery(i, searchQuery)) : uncategorized
	);
	const hasResults = $derived(filteredCategorized.length > 0 || filteredUncategorized.length > 0);

	// ── Cart helpers ─────────────────────────────────────────────────────────
	function effectivePrice(item: { price: number; discountedPrice: number | null }) {
		return item.discountedPrice ?? item.price;
	}
	function hasModifiers(item: { modifiers: unknown[] }) {
		return item.modifiers.length > 0;
	}

	// ── Add-to-cart micro-animation ──────────────────────────────────────────
	let lastAddedId = $state<number | null>(null);
	let pulsingId = $state<number | null>(null);
	let addedTimer: ReturnType<typeof setTimeout> | null = null;

	async function addSimple(item: {
		id: number;
		name: number | string;
		price: number;
		discountedPrice: number | null;
		images: unknown;
		pickupType: PickupType;
		customDateLeadDays?: number | null;
		availabilityMode?: AvailabilityMode | null;
	}) {
		const images = item.images as { url: string; isPrimary?: boolean }[] | null;
		const imageUrl = images?.find((i) => i.isPrimary)?.url ?? images?.[0]?.url;
		const addArgs = {
			itemId: item.id,
			name: String(item.name),
			basePrice: effectivePrice(item as { price: number; discountedPrice: number | null }),
			selectedModifiers: [] as CartModifier[],
			imageUrl,
			pickupType: item.pickupType,
			customDateLeadDays: item.customDateLeadDays ?? undefined,
			availabilityMode: item.availabilityMode ?? undefined
		};

		try {
			cart.add(addArgs);
		} catch (e) {
			if (e instanceof CartTypeMismatchError) {
				const confirmed = await confirmDialog(
					'Wedding cakes and other custom orders are placed separately — they have their own checkout and approval. Start a new cart for this item?',
					{
						title: 'Start a new cart?',
						confirmLabel: 'Start new cart',
						cancelLabel: 'Cancel',
						danger: true
					}
				);
				if (!confirmed) return;
				cart.clear();
				cart.add(addArgs);
			} else {
				throw e;
			}
		}

		pulsingId = item.id;
		setTimeout(() => {
			pulsingId = null;
		}, 350);

		if (addedTimer) clearTimeout(addedTimer);
		lastAddedId = item.id;
		addedTimer = setTimeout(() => {
			lastAddedId = null;
		}, 2500);
	}

	// ── Cart preview ─────────────────────────────────────────────────────────
	const cartFirstItem = $derived(
		cart.items[0]?.name
			? cart.items[0].name.length > 20
				? cart.items[0].name.slice(0, 20) + '…'
				: cart.items[0].name
			: ''
	);

	// ── IntersectionObserver: active category nav ────────────────────────────
	let activeCategoryId = $state<string | null>(null);

	onMount(() => {
		const observer = new IntersectionObserver(
			(entries) => {
				for (const entry of entries) {
					if (entry.isIntersecting) activeCategoryId = entry.target.id;
				}
			},
			{ rootMargin: '-15% 0px -75% 0px', threshold: 0 }
		);
		document.querySelectorAll('section[id]').forEach((el) => observer.observe(el));
		return () => observer.disconnect();
	});

	function scrollToSection(id: string) {
		const el = document.getElementById(id);
		if (!el) return;
		const stickyBar = document.querySelector('.sticky') as HTMLElement | null;
		const offset = (stickyBar?.offsetHeight ?? 0) + 16;
		window.scrollTo({
			top: el.getBoundingClientRect().top + window.scrollY - offset,
			behavior: 'smooth'
		});
	}
</script>

<svelte:head>
	<title>{vendor.name}</title>
</svelte:head>

<div class="min-h-screen">
	<!-- ── Banner hero or colored header ──────────────────────────────────── -->
	{#if vendor.bannerUrl}
		<div class="relative h-56 overflow-hidden sm:h-72">
			<img
				src={vendor.bannerUrl}
				alt={vendor.name}
				class="absolute inset-0 h-full w-full object-cover"
			/>
			<div class="absolute inset-0 bg-linear-to-t from-black/80 via-black/30 to-transparent"></div>
			<div class="absolute inset-x-0 bottom-0 mx-auto max-w-2xl px-6 pb-6">
				<div class="flex items-end gap-4">
					{#if vendor.logoUrl}
						<img
							src={vendor.logoUrl}
							alt={vendor.name}
							class="mb-1 h-14 w-auto max-w-36 shrink-0 object-contain drop-shadow"
							style="filter: brightness(0) invert(1);"
						/>
					{/if}
					<div>
						{#if vendor.website}
							<!-- vendor.website is an external URL; resolve() is for internal routes only -->
							<!-- eslint-disable svelte/no-navigation-without-resolve -->
							<a
								href={vendor.website}
								target="_blank"
								rel="noopener noreferrer"
								class="transition-opacity hover:opacity-80"
							>
								<h1 class="display text-3xl font-bold text-white drop-shadow">{vendor.name}</h1>
							</a>
							<!-- eslint-enable svelte/no-navigation-without-resolve -->
						{:else}
							<h1 class="display text-3xl font-bold text-white drop-shadow">{vendor.name}</h1>
						{/if}
						{#if vendor.tagline}
							<p class="mt-1 text-sm text-white/75">{vendor.tagline}</p>
						{/if}
					</div>
				</div>
			</div>
		</div>
	{:else}
		<header class="border-b" style="background-color: var(--background-color);">
			<div class="mx-auto max-w-2xl px-6 py-8">
				<div class="flex items-start gap-5">
					{#if vendor.logoUrl}
						<img
							src={vendor.logoUrl}
							alt={vendor.name}
							class="mt-1 h-14 w-auto max-w-36 shrink-0 object-contain"
						/>
					{/if}
					<div class="min-w-0 flex-1">
						{#if vendor.website}
							<!-- vendor.website is an external URL; resolve() is for internal routes only -->
							<!-- eslint-disable svelte/no-navigation-without-resolve -->
							<a
								href={vendor.website}
								target="_blank"
								rel="noopener noreferrer"
								class="transition-opacity hover:opacity-80"
							>
								<h1
									class="display text-3xl leading-tight font-bold"
									style="color: var(--foreground-color);"
								>
									{vendor.name}
								</h1>
							</a>
							<!-- eslint-enable svelte/no-navigation-without-resolve -->
						{:else}
							<h1
								class="display text-3xl leading-tight font-bold"
								style="color: var(--foreground-color);"
							>
								{vendor.name}
							</h1>
						{/if}
						{#if vendor.tagline}
							<p
								class="mt-1.5 text-sm"
								style="color: color-mix(in srgb, var(--foreground-color) 70%, transparent);"
							>
								{vendor.tagline}
							</p>
						{/if}
					</div>
				</div>
			</div>
		</header>
	{/if}

	<!-- ── Pause notice ──────────────────────────────────────────────────── -->
	{#if isPaused}
		<div class="border-b border-amber-200 bg-amber-50 px-4 py-3 text-center text-sm text-amber-800">
			<Icon icon="mdi:pause-circle-outline" class="mb-0.5 inline-block h-4 w-4 align-text-bottom" />
			Online ordering is temporarily unavailable. Check back soon.
		</div>
	{/if}

	<!-- ── Search bar ─────────────────────────────────────────────────────── -->
	{#if data.items.length > 0}
		<div class="sticky top-0 z-50 border-b bg-background/95 backdrop-blur-sm">
			<div class="mx-auto max-w-2xl px-4 pt-2">
				<!-- Search input -->
				<div class="relative mb-2">
					<Icon
						icon="mdi:magnify"
						class="absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-muted-foreground"
					/>
					<input
						type="search"
						placeholder="Search…"
						bind:value={searchQuery}
						class="w-full rounded-full border bg-muted/50 py-2 pr-4 pl-9 text-sm transition-colors outline-none focus:border-gray-400 focus:bg-background"
					/>
					{#if searchQuery}
						<button
							type="button"
							onclick={() => {
								searchQuery = '';
							}}
							class="absolute top-1/2 right-3 -translate-y-1/2 text-muted-foreground hover:text-muted-foreground"
						>
							<Icon icon="mdi:close-circle" class="h-4 w-4" />
						</button>
					{/if}
				</div>

				<!-- Category nav (hidden while searching) -->
				{#if !searchQuery && filteredCategorized.length > 0}
					<div class="overflow-x-auto">
						<div class="flex gap-1 pb-2">
							{#each filteredCategorized as category (category.id)}
								<a
									href="#{category.id}"
									onclick={(e) => {
										e.preventDefault();
										scrollToSection(String(category.id));
									}}
									class="category-pill shrink-0 rounded-full px-4 py-1.5 text-sm font-medium text-muted-foreground transition-colors {activeCategoryId ===
									String(category.id)
										? 'active'
										: ''}"
								>
									{category.name}
								</a>
							{/each}
							{#if filteredUncategorized.length > 0}
								<a
									href="#other"
									onclick={(e) => {
										e.preventDefault();
										scrollToSection('other');
									}}
									class="category-pill shrink-0 rounded-full px-4 py-1.5 text-sm font-medium text-muted-foreground transition-colors {activeCategoryId ===
									'other'
										? 'active'
										: ''}"
								>
									Other
								</a>
							{/if}
						</div>
					</div>
				{/if}
			</div>
		</div>
	{/if}

	<!-- ── Menu items ─────────────────────────────────────────────────────── -->
	<main
		class="mx-auto my-8 max-w-2xl space-y-10 rounded-2xl bg-background/80 px-4 py-8 backdrop-blur-sm"
	>
		{#if data.items.length === 0}
			<div class="rounded-xl border border-dashed p-12 text-center">
				<p class="text-muted-foreground">Coming soon.</p>
			</div>
		{:else if !hasResults}
			<div class="rounded-xl border border-dashed p-12 text-center">
				<Icon icon="mdi:magnify" class="mx-auto mb-3 h-8 w-8 text-muted-foreground/40" />
				<p class="text-muted-foreground">
					No items match "<span class="font-medium">{searchQuery}</span>"
				</p>
				<button
					type="button"
					onclick={() => {
						searchQuery = '';
					}}
					class="mt-3 text-sm font-medium"
					style="color: var(--background-color);">Clear search</button
				>
			</div>
		{:else}
			{#each filteredCategorized as category (category.id)}
				<section id={String(category.id)}>
					<h2
						class="display mb-4 border-b-2 pb-2 text-xl font-semibold text-foreground"
						style="border-color: var(--background-color);"
					>
						{category.name}
					</h2>
					<div class="space-y-3">
						{#each category.items as item (item.id)}
							{@const imgs = item.images as { url: string; isPrimary?: boolean }[] | null}
							{@const primaryImage = imgs?.find((i) => i.isPrimary)?.url ?? imgs?.[0]?.url}
							<div class="item-card flex gap-4 rounded-xl border bg-background p-4 shadow-sm">
								{#if primaryImage}
									<img
										src={primaryImage}
										alt={item.name}
										class="h-20 w-20 shrink-0 rounded-lg object-cover"
									/>
								{/if}
								<div class="min-w-0 flex-1">
									<p class="display font-semibold text-foreground">{item.name}</p>
									{#if item.description}
										<p class="mt-0.5 line-clamp-2 text-sm text-muted-foreground">
											{item.description}
										</p>
									{/if}
									{#if Array.isArray(item.tags) && item.tags.length > 0}
										<div class="mt-1.5 flex flex-wrap gap-1">
											{#each item.tags as tag (tag)}
												<span
													class="rounded-full px-2 py-0.5 text-xs capitalize"
													style="background-color: color-mix(in srgb, var(--accent-color) 15%, white); color: var(--accent-color);"
													>{tag.toLowerCase()}</span
												>
											{/each}
										</div>
									{/if}
								</div>
								<div class="flex shrink-0 flex-col items-end justify-between gap-2">
									<div class="text-right">
										{#if item.discountedPrice}
											<p class="font-semibold" style="color: var(--background-color);">
												${(item.discountedPrice / 100).toFixed(2)}
											</p>
											<p class="text-xs text-muted-foreground line-through">
												${(item.price / 100).toFixed(2)}
											</p>
										{:else}
											<p class="font-semibold text-foreground">${(item.price / 100).toFixed(2)}</p>
										{/if}
										{#if item.availabilityMode === 'storefront_only'}
											<p class="mt-0.5 text-xs text-muted-foreground">Storefront pickup</p>
										{:else if item.availabilityMode === 'events_only'}
											<p class="mt-0.5 text-xs text-muted-foreground">Event pickup only</p>
										{:else if item.availabilityMode === 'special_order'}
											<p class="mt-0.5 text-xs text-muted-foreground">Special order</p>
										{/if}
									</div>
									{#if item.status === 'sold_out'}
										<span
											class="rounded-lg bg-amber-100 px-3 py-1.5 text-xs font-medium text-amber-700"
											>Sold out</span
										>
									{:else if isPaused}
										<span
											class="rounded-lg bg-gray-100 px-3 py-1.5 text-xs font-medium text-gray-400"
											>Unavailable</span
										>
									{:else if hasModifiers(item)}
										<a
											href={resolve(`/${data.vendorSlug}/item/${item.id}`)}
											style="border-color: var(--background-color); color: var(--background-color);"
											class="rounded-lg border px-3 py-1.5 text-xs font-medium transition-opacity hover:opacity-75"
											>Options</a
										>
									{:else}
										<button
											type="button"
											onclick={() => addSimple(item)}
											class="add-btn rounded-lg px-3 py-1.5 text-xs font-medium transition-all {pulsingId ===
											item.id
												? 'pulsing'
												: ''} {lastAddedId === item.id ? 'added' : ''}"
											style="background-color: var(--background-color); color: var(--foreground-color);"
										>
											{lastAddedId === item.id ? '✓ Added' : '+ Add'}
										</button>
									{/if}
								</div>
							</div>
						{/each}
					</div>
				</section>
			{/each}

			{#if filteredUncategorized.length > 0}
				<section id="other">
					{#if filteredCategorized.length > 0}
						<h2
							class="display mb-4 border-b-2 pb-2 text-xl font-semibold text-foreground"
							style="border-color: var(--background-color);"
						>
							Other
						</h2>
					{/if}
					<div class="space-y-3">
						{#each filteredUncategorized as item (item.id)}
							{@const imgs = item.images as { url: string; isPrimary?: boolean }[] | null}
							{@const primaryImage = imgs?.find((i) => i.isPrimary)?.url ?? imgs?.[0]?.url}
							<div class="item-card flex gap-4 rounded-xl border bg-background p-4 shadow-sm">
								{#if primaryImage}
									<img
										src={primaryImage}
										alt={item.name}
										class="h-20 w-20 shrink-0 rounded-lg object-cover"
									/>
								{/if}
								<div class="min-w-0 flex-1">
									<p class="display font-semibold text-foreground">{item.name}</p>
									{#if item.description}
										<p class="mt-0.5 line-clamp-2 text-sm text-muted-foreground">
											{item.description}
										</p>
									{/if}
									{#if Array.isArray(item.tags) && item.tags.length > 0}
										<div class="mt-1.5 flex flex-wrap gap-1">
											{#each item.tags as tag (tag)}
												<span
													class="rounded-full px-2 py-0.5 text-xs capitalize"
													style="background-color: color-mix(in srgb, var(--accent-color) 15%, white); color: var(--accent-color);"
													>{tag.toLowerCase()}</span
												>
											{/each}
										</div>
									{/if}
								</div>
								<div class="flex shrink-0 flex-col items-end justify-between gap-2">
									<div class="text-right">
										{#if item.discountedPrice}
											<p class="font-semibold" style="color: var(--background-color);">
												${(item.discountedPrice / 100).toFixed(2)}
											</p>
											<p class="text-xs text-muted-foreground line-through">
												${(item.price / 100).toFixed(2)}
											</p>
										{:else}
											<p class="font-semibold text-foreground">${(item.price / 100).toFixed(2)}</p>
										{/if}
										{#if item.availabilityMode === 'storefront_only'}
											<p class="mt-0.5 text-xs text-muted-foreground">Storefront pickup</p>
										{:else if item.availabilityMode === 'events_only'}
											<p class="mt-0.5 text-xs text-muted-foreground">Event pickup only</p>
										{:else if item.availabilityMode === 'special_order'}
											<p class="mt-0.5 text-xs text-muted-foreground">Special order</p>
										{/if}
									</div>
									{#if item.status === 'sold_out'}
										<span
											class="rounded-lg bg-amber-100 px-3 py-1.5 text-xs font-medium text-amber-700"
											>Sold out</span
										>
									{:else if isPaused}
										<span
											class="rounded-lg bg-gray-100 px-3 py-1.5 text-xs font-medium text-gray-400"
											>Unavailable</span
										>
									{:else if hasModifiers(item)}
										<a
											href={resolve(`/${data.vendorSlug}/item/${item.id}`)}
											style="border-color: var(--background-color); color: var(--background-color);"
											class="rounded-lg border px-3 py-1.5 text-xs font-medium transition-opacity hover:opacity-75"
											>Options</a
										>
									{:else}
										<button
											type="button"
											onclick={() => addSimple(item)}
											class="add-btn rounded-lg px-3 py-1.5 text-xs font-medium transition-all {pulsingId ===
											item.id
												? 'pulsing'
												: ''} {lastAddedId === item.id ? 'added' : ''}"
											style="background-color: var(--background-color); color: var(--foreground-color);"
										>
											{lastAddedId === item.id ? '✓ Added' : '+ Add'}
										</button>
									{/if}
								</div>
							</div>
						{/each}
					</div>
				</section>
			{/if}
		{/if}
	</main>

	<!-- ── Sticky cart bar ────────────────────────────────────────────────── -->
	{#if cart.count > 0 && !isPaused}
		<div class="sticky bottom-0 flex justify-center p-4">
			<a
				href={resolve(`/${data.vendorSlug}/cart` as `/${string}`)}
				style="background-color: var(--background-color); color: var(--foreground-color);"
				class="flex w-full max-w-2xl items-center justify-between rounded-xl px-5 py-3.5 shadow-lg transition-opacity hover:opacity-90"
			>
				<span class="flex items-center gap-1.5">
					<span
						class="flex h-6 w-6 items-center justify-center rounded-full bg-background/20 text-sm font-bold"
						>{cart.count}</span
					>
					<span class="text-sm font-medium opacity-80">{cart.count === 1 ? 'item' : 'items'}</span>
				</span>
				<span class="min-w-0 truncate px-2 text-sm font-medium opacity-80">{cartFirstItem}</span>
				<span class="shrink-0 font-semibold">View Cart → ${(cart.subtotal / 100).toFixed(2)}</span>
			</a>
		</div>
	{/if}
</div>

<style>
	/* Category nav active + hover */
	.category-pill:hover,
	.category-pill.active {
		background-color: var(--accent-color);
		color: var(--foreground-color);
	}

	/* Item card fade-in stagger */
	@keyframes fadeUp {
		from {
			opacity: 0;
			transform: translateY(10px);
		}
		to {
			opacity: 1;
			transform: translateY(0);
		}
	}
	.item-card {
		animation: fadeUp 0.2s ease both;
	}

	.display {
		font-family: 'Fraunces', Georgia, serif;
	}

	/* Add button pulse animation */
	@keyframes addPulse {
		0% {
			transform: scale(1);
		}
		40% {
			transform: scale(1.18);
		}
		100% {
			transform: scale(1);
		}
	}
	.add-btn:hover:not(.added) {
		opacity: 0.82;
	}
	.add-btn.pulsing {
		animation: addPulse 0.35s cubic-bezier(0.36, 0.07, 0.19, 0.97) both;
	}
	.add-btn.added {
		background-color: var(--accent-color) !important;
		color: var(--foreground-color) !important;
	}
</style>
