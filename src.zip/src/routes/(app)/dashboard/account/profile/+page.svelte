<script lang="ts">
	import { enhance } from '$app/forms';
	import type { PageData, ActionData } from './$types';
	import { Button } from '$lib/components/ui/button';
	import { Input } from '$lib/components/ui/input';
	import { Label } from '$lib/components/ui/label';
	import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '$lib/components/ui/card';
	import { Alert } from '$lib/components/ui/alert';

	let { data, form }: { data: PageData; form: ActionData } = $props();
</script>

<div class="max-w-xl">
	<div class="mb-6">
		<h1 class="text-2xl font-bold text-foreground">Profile</h1>
		<p class="mt-0.5 text-sm text-muted-foreground">Update your personal information.</p>
	</div>

	<div class="space-y-6">
		<!-- Profile info -->
		<Card class="shadow-sm">
			<CardHeader>
				<CardTitle>Personal information</CardTitle>
			</CardHeader>
			<CardContent>
				{#if form?.profileError}
					<Alert severity="error" class="mb-4">{form.profileError}</Alert>
				{/if}
				{#if form?.profileSuccess}
					<Alert severity="success" class="mb-4">Profile updated.</Alert>
				{/if}

				<form
					id="profile-form"
					method="post"
					action="?/updateProfile"
					use:enhance
					class="space-y-4"
				>
					<div>
						<Label class="mb-1 block" for="name">Name</Label>
						<Input id="name" name="name" type="text" required value={data.user.name} />
					</div>
					<div>
						<Label class="mb-1 block" for="email">Email</Label>
						<Input id="email" type="email" value={data.user.email} disabled />
						<p class="mt-1 text-xs text-muted-foreground">Email cannot be changed here.</p>
					</div>
				</form>
			</CardContent>
			<CardFooter>
				<Button type="submit" form="profile-form" variant="default">Save changes</Button>
			</CardFooter>
		</Card>
	</div>
</div>
